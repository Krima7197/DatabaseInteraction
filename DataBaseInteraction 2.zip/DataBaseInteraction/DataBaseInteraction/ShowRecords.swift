

import UIKit

class ShowRecords: UIViewController {

    
    @IBOutlet weak var txtName: UITextField!
    
    @IBOutlet weak var txtAddress: UITextField!
    
    @IBOutlet weak var lblShow: UILabel!
    
    
   
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    @IBAction func btnPrev(_ sender: Any)
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func btnShow(_ sender: Any)
    {   let url = URL(string: "http://localhost/KrimaDB/SerivceGetFromDB.php?name=\(txtName.text!)&address=\(txtAddress.text!)")
        let request = URLRequest(url: url!)
        let session = URLSession.shared
        let datatask = session.dataTask(with: request) { (data1, resp, err) in
            let strrep = String(data: data1!, encoding: String.Encoding.utf8)
            DispatchQueue.main.async
            {
                self.lblShow.text = strrep
            }
        }
    datatask.resume()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }
    

}
