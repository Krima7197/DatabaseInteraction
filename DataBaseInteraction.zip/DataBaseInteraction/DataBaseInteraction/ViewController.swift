
import UIKit

class ViewController: UIViewController {

   
    @IBOutlet weak var lblResult: UILabel!
    @IBOutlet weak var txtMno: UITextField!
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtAdd: UITextField!
    @IBOutlet weak var txtId: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }

    
    @IBAction func btnInsert(_ sender: Any)
    {
        let url = URL(string: "http://localhost/KrimaDB/SerivceInsertInDB.php?id=\(txtId.text!)&name=\(txtName.text!)&address=\(txtAdd.text!)&mon=\(txtMno.text!)")
        let request = URLRequest(url: url!)
        let session = URLSession.shared
        let datatask = session.dataTask(with: request) { (data1, resp, err) in
            let strrep = String(data: data1!, encoding: String.Encoding.utf8)
            DispatchQueue.main.async {
                self.lblResult.text = strrep
            }
        }
        datatask.resume()
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
            }


}

